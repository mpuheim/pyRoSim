#!/usr/bin/python2.6
# This Python file uses the following encoding: utf-8
from modules import gui, simulation
from modules.utils import struct
from modules.config import res
from math import sqrt
import time
import sys, os
import pygame
### draws track onto the pygame screen
def showTrack(name, width):
  try:
    with open(name) as f: f = open(name)  ### nebudem tu pisat kod a robit bordel, checkol som co som musel
  except IOError as e:
    print 'I couldnt find such file.'
    sys.exit()
  for line in iter(f):
#    print line
    x, y, junk = line.split(None)
#    print x, y, junk
    junk.strip()  ### preistotu aby niekoho nejeblo ozem ked bude hladat kde mu ostava LF
    gui.DrawDot(screen, int(x), int(y))
    addCoordinates(track, width, x, y)
#    print x, y, junk
### add coordinates separated with comma as string into the track list
def addCoordinates(l, w, x, y):
  if checkList(l, w, x, y):
    l.append(str(x) + ',' + str(y))
    gui.DrawDot(screen, int(x), int(y))
#    print "appended: ", x, y
### checks whether my last coordinates are same as new ones
def checkList(l, w, x, y):
  if len(l) == 0:
    return 1
  a, b = l[-1].split(',')
#  print a, sep, b
  if (a == None or b == None):
    print "Unexpected error. Exitting"  # checks possible inconsistency
    sys.exit()
#  hamilton = abs(int(a) - x) + abs(int(b) - y)
  euclyde = sqrt((int(a) - int(x))**2 + (int(b) - int(y))**2)
#  print a, b, x, y
#  print euclyde, w
  if euclyde > w:
#    print 'idze', euclyde, w
    return 1
  else:
#    print 'nejdze', euclyde, w
    return 0
def writeFile(name, l):
  f = open(name, 'w')
  for i in l:
    x, y = i.split(',')
    f.write(str(x) + ' ' + str(y) + ' ' + str(width) + os.linesep)
  f.close()
### list of track coordinates
track = []
width = 10   # temporary width for a track, uniform in all parts of the track
### screen initialization
screen = gui.Init(res)
# run main loop
run = 1
### show track from file # TODO # make command line switches and tidy up this mess
#print sys.argv[0], sys.argv[1], sys.argv[2], len(sys.argv)
if len(sys.argv) == 3 and sys.argv[1] == 'show':
  showTrack(sys.argv[2], width)
  sys.argv.pop()
  sys.argv.pop()
#  pygame.display.update()
while (run):
  #  refresh gui screen
#  run = gui.Refresh(screen, car)
#  print 'Placeholder'
#  gui.MouseButtons()
#  run = gui.Events()
#  run = pygame.event.pump()
  pygame.event.pump()
#  x, y = gui.Coordinates()
#  left, middle, right = gui.Buttons()
  x, y = pygame.mouse.get_pos()
  left, middle, right = pygame.mouse.get_pressed()
#  print "X " + str(x) + " Y " + str(y)
#  print "LEFT " + str(left) + " RIGHT " + str(right) + " MIDDLE " + str(middle)
#  time.sleep(0.1)
  if left:
#    gui.DrawDot(screen, x, y)
    addCoordinates(track, width, x, y) 
#    gui.DrawRect(screen, x, y)
  elif middle:  ### reset track
    gui.ClrScr(screen)
    track = []
#  elif right:  ### no delete, breaks order of sequence for track coordinates
#    gui.DeleteDot(screen, x, y)
  elif right:
    if len(sys.argv) == 1:
      track_name = raw_input('Zadaj nazov trate: ')
    else:
      track_name = sys.argv[1]
    writeFile(track_name + ".nft", track)
    sys.exit()
#  pygame.display.flip()
  pygame.display.update()
#  if len(track) > 300:
#    print track
#    sys.exit()
