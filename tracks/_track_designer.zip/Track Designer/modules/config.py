﻿# This Python file uses the following encoding: utf-8

#---CONFIGURATION-FILE---#

res = (500,500) # screen resolution
step = 0.1 # basic simulation step

#---END-OF-CONFIGURATION-FILE---#
