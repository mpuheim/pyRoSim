﻿# This Python file uses the following encoding: utf-8

import pygame
from modules.config import step

def Init(res):
    # Open a display window
    pygame.init()
    screen=pygame.display.set_mode((res[0],res[1]))
    pygame.display.set_caption('Track Designer')
    pygame.font.init()
    return screen
    
def ClrScr(screen):
    # Change entire screen to black color
    screen.fill((0, 0, 0))
    
def DrawDot(screen, x, y):
    # Draw dot on screen
    pygame.draw.circle(screen, (255, 255, 255), (x,y), 1, 1)
    
def DrawLine(screen, x1, y1, x2, y2):
    # Draw line on screen
    pygame.draw.line(screen, (255, 255, 255), (x1, y1), (x2, y2))
    
def HandleEvents(car):
    # Handle events
    while 1:
        # get event from event poll
        event = pygame.event.poll()
        # stop handling if event poll is empty
        if event.type == pygame.NOEVENT:
            return 1
        # return 0 if exit button is pressed
        if event.type == pygame.QUIT:
            return 0
        # handle car speed and turn parameters
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_LEFT:
                car.update(turn = car.turn-step)
            elif event.key == pygame.K_RIGHT:
                car.update(turn = car.turn+step)
            elif event.key == pygame.K_UP:
                car.update(speed = car.speed+step)
            elif event.key == pygame.K_DOWN:
                car.update(speed = car.speed-step)              
    
def Refresh(screen, car):
    # Handle events
    if HandleEvents(car) == 0:
        return 0
    # Clear screen
    ClrScr(screen)
    # Update car position
    car.move()
    # Show car on screen
    x = int(round(car.x_pos))
    y = int(round(car.y_pos))
    DrawDot(screen,x,y)
    # Show info
    font = pygame.font.SysFont("Courier",12)
    string = "Speed=" + str(car.speed) + "  Turn=" + str(car.turn) + "  Direction=" + str(car.direction) + "  Pos: X=" + str(car.x_pos) + " Y=" + str(car.y_pos)
    screen.blit(font.render(string, True, (200,200,200)), (5,5))
    # Screen refresh
    pygame.display.flip()
    return 1
