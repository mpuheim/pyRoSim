﻿# This Python file uses the following encoding: utf-8

from math import sin, cos
from modules.config import res
degree_to_radian = 0.0174532925
radian_to_degree = 57.2957795

class Car():
    # Car class
    def __init__(self,speed=0.0,direction=0.0,acceleration=0.0,turn=0.0,x_pos=float(res[0]/2),y_pos=float(res[1]/2)):
        self.speed = speed
        self.direction = direction
        self.acceleration = acceleration
        self.turn = turn
        self.x_pos = x_pos
        self.y_pos = y_pos
    # Update class parameters
    def update(self, *args, **kwargs):
        for k, v in kwargs.items():
            setattr(self, k, v)
    # Move car using current speed and orientation
    def move(self):
        self.direction = (self.direction + self.turn + 360)%360
        radian = self.direction*degree_to_radian
        self.x_pos = (self.x_pos + self.speed * cos(radian))%res[0]
        self.y_pos = (self.y_pos + self.speed * sin(radian))%res[1]
        
class Track():
    # Track class
    def __init__():
        pass
